#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const readline = require('readline');
const os = require('os');

const CONFIG_FILE = path.join(os.homedir(), '.acseo-commit.json');

// Configuration par défaut
const defaultConfig = {
  aiProvider: 'claude', // 'claude' ou 'openai'
  apiKey: '',
  language: 'french'
};

/**
 * Vérifie si la configuration existe déjà
 */
function configExists() {
  return fs.existsSync(CONFIG_FILE);
}

/**
 * Sauvegarde la configuration
 */
function saveConfig(config) {
  try {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error(`Erreur lors de la sauvegarde de la configuration: ${error.message}`);
    return false;
  }
}

/**
 * Configure l'outil de manière interactive
 */
async function setupConfig() {
  if (configExists()) {
    console.log(`\n✅ Configuration trouvée dans ${CONFIG_FILE}`);
    console.log('Pour modifier la configuration, exécutez: acseo-commit --config');
    return;
  }

  console.log('\n🔧 Configuration initiale de ACSEO Commit');
  console.log('----------------------------------------');
  console.log('Cette configuration peut être modifiée ultérieurement avec "acseo-commit --config"\n');

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  // Définir la configuration par défaut
  const config = { ...defaultConfig };

  console.log('Pour générer des descriptions de commit avec IA, vous aurez besoin d\'une clé API.');
  console.log('Vous pouvez configurer cela plus tard si vous le souhaitez.\n');

  try {
    const aiProvider = await new Promise(resolve => {
      rl.question('Fournisseur d\'IA (claude/openai) [claude]: ', answer => {
        resolve(answer.trim().toLowerCase() || 'claude');
      });
    });

    config.aiProvider = aiProvider === 'openai' ? 'openai' : 'claude';

    // Demander la clé API seulement si l'utilisateur ne ferme pas le programme
    const providerName = config.aiProvider === 'openai' ? 'OpenAI' : 'Claude (Anthropic)';
    const apiKey = await new Promise(resolve => {
      rl.question(`Clé API ${providerName} (optionnel, peut être configurée plus tard): `, answer => {
        resolve(answer.trim());
      });
    });

    if (apiKey) {
      config.apiKey = apiKey;
    }

    const language = await new Promise(resolve => {
      rl.question('Langue par défaut (french/english) [french]: ', answer => {
        resolve(answer.trim().toLowerCase() || 'french');
      });
    });

    config.language = language === 'english' ? 'english' : 'french';

    // Fermer l'interface readline
    rl.close();

    // Sauvegarder la configuration
    if (saveConfig(config)) {
      console.log(`\n✅ Configuration sauvegardée dans ${CONFIG_FILE}`);
    } else {
      console.log('\n⚠️ La configuration n\'a pas pu être sauvegardée');
    }
  } catch (err) {
    console.error('Erreur lors de la configuration:', err);
    rl.close();
  }
}

// Exécution principale
setupConfig().catch(err => {
  console.error('Erreur lors de l\'installation:', err);
});