# ACSEO Commit

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)

Un outil en ligne de commande pour générer des messages de commit conformes à la convention ACSEO, avec analyse par intelligence artificielle des modifications.

## Caractéristiques

- 🚀 **Simple à utiliser** - Une seule commande `acseo-commit`
- 🔍 **Analyse intelligente** - Utilise l'IA (Claude ou ChatGPT) pour analyser vos modifications
- 📝 **Convention ACSEO** - Respect strict de la convention de nommage ACSEO
- 📋 **Interface interactive** - Guide l'utilisateur étape par étape
- 🌍 **Support multilingue** - Disponible en français et en anglais
- 🍺 **Installable via Homebrew** - Pour les utilisateurs macOS

## Installation

### Via Homebrew (macOS)

```bash
brew tap acseo/tools
brew install acseo-commit
```

### Via npm

```bash
npm install -g acseo-commit
```

## Utilisation

1. Ajoutez vos fichiers modifiés à l'index Git :
```bash
git add .
```

2. Lancez ACSEO Commit :
```bash
acseo-commit
```

3. Suivez les instructions interactives pour générer votre message de commit.

## Exemples

### Exemple simple sans IA
```
$ acseo-commit

🚀 ACSEO Commit - Générateur de commits conventionnels

=== Fichiers en attente de commit ===
------------------------------------
Modifié (1):
  - src/Controller/UserController.php
------------------------------------

=== Types de commit disponibles ===
1. build: Modifications liées au système de build ou dépendances
...
6. fix: Correction d'un bug
...

Choisissez le type de commit (1-11) : 6

Numéro de ticket (obligatoire) : #45678

Souhaitez-vous ajouter un scope ? (o/N) : o
Entrez le scope : user

Description du commit : corrige validation de formulaire

=== Message de commit proposé ===
fix(#45678, user): corrige validation de formulaire
================================

Effectuer le commit avec ce message ? (O/n) : O

✅ Commit effectué avec succès !
```

### Exemple avec analyse IA
```
$ acseo-commit

🚀 ACSEO Commit - Générateur de commits conventionnels
...

🤖 Analyse des modifications avec IA en cours...

1. Standard: modifie 2 fichiers dans src
2. IA: corrige problème d'authentification dans le form login
3. Personnalisée

Choisissez une option (1/2/3): 2

=== Message de commit proposé ===
fix(#56789): corrige problème d'authentification dans le form login
================================

Effectuer le commit avec ce message ? (O/n) : O

✅ Commit effectué avec succès !
```

## Configuration

Lors de la première utilisation, ACSEO Commit vous guidera pour configurer votre clé API et vos préférences. Vous pouvez modifier cette configuration à tout moment :

```bash
acseo-commit --config
```

La configuration est stockée dans `~/.acseo-commit.json`.

## Obtenir une clé API

Pour utiliser les fonctionnalités d'IA, vous aurez besoin d'une clé API :

- **Claude (Anthropic)** : [https://console.anthropic.com/](https://console.anthropic.com/)
- **ChatGPT (OpenAI)** : [https://platform.openai.com/](https://platform.openai.com/)

## Développement

### Installation locale pour développement

```bash
git clone https://github.com/acseo/acseo-commit.git
cd acseo-commit
npm install
npm link
``` 
test

### Structure du projet

```
acseo-commit/
├── acseo-commit.js    # Script principal
├── package.json       # Métadonnées npm
├── scripts/           # Scripts utilitaires
└── README.md          # Documentation
```

## Licence

MIT