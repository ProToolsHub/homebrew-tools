#!/usr/bin/env node

const { execSync } = require('child_process');
const fs = require('fs');
const readline = require('readline');
const path = require('path');
const https = require('https');
const os = require('os');

// Configuration du fichier
const CONFIG_FILE = path.join(os.homedir(), '.acseo-commit.json');

// Configuration par défaut
let config = {
	aiProvider: 'claude', // 'claude' ou 'openai'
	apiKey: '',
	language: 'french'
};

// Liste des types de commit selon la convention ACSEO
const COMMIT_TYPES = [
	{ value: 'build', desc: 'Modifications liées au système de build ou dépendances' },
	{ value: 'chore', desc: 'Tâches sans impact sur le code applicatif' },
	{ value: 'ci', desc: 'Modifications pour les systèmes d\'intégration continue' },
	{ value: 'docs', desc: 'Ajout ou mise à jour de la documentation' },
	{ value: 'feat', desc: 'Introduction d\'une nouvelle fonctionnalité' },
	{ value: 'fix', desc: 'Correction d\'un bug' },
	{ value: 'perf', desc: 'Amélioration des performances' },
	{ value: 'refactor', desc: 'Modification du code sans changer son comportement' },
	{ value: 'revert', desc: 'Annulation d\'un commit précédent' },
	{ value: 'style', desc: 'Modifications sans impact fonctionnel (style du code)' },
	{ value: 'test', desc: 'Ajout ou modification des tests' }
];

/**
 * Charge la configuration
 */
function loadConfig() {
	try {
		if (fs.existsSync(CONFIG_FILE)) {
			const loadedConfig = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
			config = { ...config, ...loadedConfig };
		}
	} catch (error) {
		console.error('Erreur lors du chargement de la configuration:', error.message);
	}
}

/**
 * Sauvegarde la configuration
 */
function saveConfig() {
	try {
		fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
		console.log(`Configuration sauvegardée dans ${CONFIG_FILE}`);
	} catch (error) {
		console.error('Erreur lors de la sauvegarde de la configuration:', error.message);
	}
}

/**
 * Configure l'outil
 */
async function setupConfig() {
	const rl = createReadlineInterface();
	console.log('\n=== Configuration de ACSEO Commit ===');

	return new Promise((resolve) => {
		rl.question(`Fournisseur d'IA (claude/openai) [${config.aiProvider}]: `, (aiProvider) => {
			if (aiProvider.trim() !== '') {
				config.aiProvider = aiProvider.toLowerCase();
			}

			const providerName = config.aiProvider === 'openai' ? 'OpenAI (ChatGPT)' : 'Anthropic (Claude)';
			rl.question(`Clé API pour ${providerName} [masquée]: `, (apiKey) => {
				if (apiKey.trim() !== '') {
					config.apiKey = apiKey;
				}

				rl.question(`Langue (french/english) [${config.language}]: `, (language) => {
					if (language.trim() !== '') {
						config.language = language.toLowerCase();
					}

					rl.close();
					saveConfig();
					resolve();
				});
			});
		});
	});
}

/**
 * Crée une interface de lecture en ligne de commande
 */
function createReadlineInterface() {
	return readline.createInterface({
		input: process.stdin,
		output: process.stdout
	});
}

/**
 * Obtient les fichiers modifiés en attente de commit
 */
function getChangedFiles() {
	try {
		const output = execSync('git diff --cached --name-status').toString();
		return output
			.split('\n')
			.filter(line => line.trim() !== '')
			.map(line => {
				const [status, file] = line.split('\t');
				return { status, file };
			});
	} catch (error) {
		console.error('Erreur lors de la récupération des fichiers modifiés:', error.message);
		return [];
	}
}

/**
 * Affiche un résumé des fichiers en attente de commit
 */
function displayChangedFilesSummary(files) {
	const statusMap = {
		'A': 'Ajouté',
		'M': 'Modifié',
		'D': 'Supprimé',
		'R': 'Renommé'
	};

	console.log('\n=== Fichiers en attente de commit ===');
	console.log('------------------------------------');

	const byStatus = {};
	files.forEach(file => {
		const statusChar = file.status.charAt(0);
		if (!byStatus[statusChar]) {
			byStatus[statusChar] = [];
		}
		byStatus[statusChar].push(file.file);
	});

	for (const [status, fileList] of Object.entries(byStatus)) {
		const statusText = statusMap[status] || 'Modifié';
		console.log(`\n${statusText} (${fileList.length}):`);
		fileList.forEach(file => {
			console.log(`  - ${file}`);
		});
	}
	console.log('\n------------------------------------');
}

/**
 * Demande le type de commit à l'utilisateur
 */
async function promptCommitType() {
	const rl = createReadlineInterface();

	console.log('\n=== Types de commit disponibles ===');
	COMMIT_TYPES.forEach((type, index) => {
		console.log(`${index + 1}. ${type.value}: ${type.desc}`);
	});

	return new Promise((resolve) => {
		rl.question('\nChoisissez le type de commit (1-11) : ', (answer) => {
			rl.close();

			const index = parseInt(answer) - 1;
			if (index >= 0 && index < COMMIT_TYPES.length) {
				resolve(COMMIT_TYPES[index].value);
			} else {
				console.log('Type non valide, utilisation de "fix" par défaut.');
				resolve('fix');
			}
		});
	});
}

/**
 * Demande le numéro de ticket à l'utilisateur
 */
async function promptTicketNumber() {
	const rl = createReadlineInterface();

	return new Promise((resolve) => {
		rl.question('\nNuméro de ticket (obligatoire) : #', (answer) => {
			rl.close();

			if (answer.trim() === '') {
				console.log('Aucun numéro de ticket fourni. Veuillez réessayer.');
				// Appel récursif pour continuer à demander jusqu'à obtenir une valeur
				resolve(promptTicketNumber());
			} else {
				resolve(answer.trim());
			}
		});
	});
}

/**
 * Demande la description du commit à l'utilisateur
 */
async function promptDescription(suggestedDesc = '') {
	const rl = createReadlineInterface();

	const prompt = suggestedDesc
		? `\nDescription du commit [${suggestedDesc}] : `
		: '\nDescription du commit : ';

	return new Promise((resolve) => {
		rl.question(prompt, (answer) => {
			rl.close();

			if (answer.trim() === '' && suggestedDesc) {
				resolve(suggestedDesc);
			} else if (answer.trim() === '') {
				console.log('La description ne peut pas être vide. Veuillez réessayer.');
				resolve(promptDescription(suggestedDesc));
			} else {
				resolve(answer.trim());
			}
		});
	});
}

/**
 * Génère une description suggérée basée sur les fichiers modifiés
 */
function generateSuggestedDescription(files) {
	// Regrouper par dossier
	const folders = {};
	files.forEach(file => {
		const parts = file.file.split('/');
		const folder = parts.length > 1 ? parts[0] : 'racine';

		if (!folders[folder]) {
			folders[folder] = [];
		}
		folders[folder].push(file);
	});

	const folderNames = Object.keys(folders);

	if (folderNames.length === 1) {
		const folder = folderNames[0];
		const count = folders[folder].length;

		if (folder === 'racine') {
			return `modifie ${count} fichier${count > 1 ? 's' : ''}`;
		} else {
			return `modifie ${count} fichier${count > 1 ? 's' : ''} dans ${folder}`;
		}
	} else {
		return `modifie ${files.length} fichier${files.length > 1 ? 's' : ''} dans plusieurs dossiers`;
	}
}

/**
 * Demande une confirmation pour le message de commit
 */
async function confirmCommit(message) {
	const rl = createReadlineInterface();

	return new Promise((resolve) => {
		console.log('\n=== Message de commit proposé ===');
		console.log(message);
		console.log('================================');

		rl.question('\nEffectuer le commit avec ce message ? (O/n) : ', (answer) => {
			rl.close();
			resolve(answer.toLowerCase() !== 'n');
		});
	});
}

/**
 * Exécute le commit avec le message
 */
function doCommit(message) {
	try {
		execSync(`git commit -m "${message.replace(/"/g, '\\"')}"`);
		console.log('\n✅ Commit effectué avec succès !');
		return true;
	} catch (error) {
		console.error('\n❌ Erreur lors du commit:', error.message);
		return false;
	}
}

/**
 * Demande si l'utilisateur veut ajouter un scope optionnel
 */
async function promptScope() {
	const rl = createReadlineInterface();

	return new Promise((resolve) => {
		rl.question('\nSouhaitez-vous ajouter un scope ? (o/N) : ', (answer) => {
			if (answer.toLowerCase() === 'o') {
				rl.question('Entrez le scope : ', (scope) => {
					rl.close();
					resolve(scope.trim() !== '' ? scope.trim() : null);
				});
			} else {
				rl.close();
				resolve(null);
			}
		});
	});
}

/**
 * Obtient les différences de fichiers pour l'analyse IA
 */
function getFilesDiff() {
	try {
		// Obtenir le diff complet
		const diff = execSync('git diff --cached').toString();

		// Limiter la taille si nécessaire (certaines API ont des limites)
		const MAX_DIFF_SIZE = 20000;
		if (diff.length > MAX_DIFF_SIZE) {
			return diff.substring(0, MAX_DIFF_SIZE) + '\n[Diff tronqué car trop volumineux...]';
		}

		return diff;
	} catch (error) {
		console.error('Erreur lors de la récupération du diff:', error.message);
		return '';
	}
}

/**
 * Analyse les modifications avec Claude (Anthropic)
 */
function analyzeWithClaude(diff, ticketNumber, commitType) {
	return new Promise((resolve, reject) => {
		if (!config.apiKey) {
			resolve(null);
			return;
		}

		const apiUrl = 'https://api.anthropic.com/v1/messages';

		const payload = JSON.stringify({
			model: "claude-3-haiku-20240307",
			max_tokens: 1000,
			messages: [
				{
					role: "user",
					content: `Voici les modifications que j'ai apportées à mon code (format git diff) :
          
${diff}

J'ai besoin que tu génères une description concise pour un message de commit, en respectant strictement les règles suivantes :
- Utiliser le mode impératif (ex: "ajoute" et non "ajout de")
- Ne pas mettre de majuscule au début
- Ne pas mettre de point à la fin
- Être précis et clair
- Utiliser maximum 10 mots
- Écrire en ${config.language}

Le type de commit est : ${commitType}
Le numéro de ticket est : #${ticketNumber}

Ne me donne que la description, sans ajouter d'autre texte.`
				}
			]
		});

		const options = {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
				'x-api-key': config.apiKey,
				'anthropic-version': '2023-06-01'
			}
		};

		const req = https.request(apiUrl, options, (res) => {
			let data = '';

			res.on('data', (chunk) => {
				data += chunk;
			});

			res.on('end', () => {
				try {
					if (res.statusCode >= 200 && res.statusCode < 300) {
						const response = JSON.parse(data);
						if (response.content && response.content.length > 0) {
							const description = response.content[0].text.trim();
							resolve(description);
						} else {
							resolve(null);
						}
					} else {
						console.error(`Erreur API Claude: ${res.statusCode}`);
						console.error(data);
						resolve(null);
					}
				} catch (error) {
					console.error('Erreur lors du parsing de la réponse Claude:', error.message);
					resolve(null);
				}
			});
		});

		req.on('error', (error) => {
			console.error('Erreur lors de la requête à l\'API Claude:', error.message);
			resolve(null);
		});

		req.write(payload);
		req.end();
	});
}

/**
 * Analyse les modifications avec OpenAI (ChatGPT)
 */
function analyzeWithOpenAI(diff, ticketNumber, commitType) {
	return new Promise((resolve, reject) => {
		if (!config.apiKey) {
			resolve(null);
			return;
		}

		const apiUrl = 'https://api.openai.com/v1/chat/completions';

		const payload = JSON.stringify({
			model: "gpt-3.5-turbo",
			temperature: 0.7,
			max_tokens: 100,
			messages: [
				{
					role: "system",
					content: `Tu es un expert en développement logiciel spécialisé dans la génération de messages de commit Git. Ta tâche est de produire une description concise et précise pour un message de commit, en respectant ces règles:
- Utiliser le mode impératif
- Ne pas mettre de majuscule au début
- Ne pas mettre de point à la fin
- Être précis et clair
- Utiliser maximum 10 mots
- Écrire en ${config.language}`
				},
				{
					role: "user",
					content: `Voici les modifications (git diff) :
          
${diff}

Type de commit : ${commitType}
Numéro de ticket : #${ticketNumber}

Génère uniquement la description du commit, sans aucun texte supplémentaire.`
				}
			]
		});

		const options = {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
				'Authorization': `Bearer ${config.apiKey}`
			}
		};

		const req = https.request(apiUrl, options, (res) => {
			let data = '';

			res.on('data', (chunk) => {
				data += chunk;
			});

			res.on('end', () => {
				try {
					if (res.statusCode >= 200 && res.statusCode < 300) {
						const response = JSON.parse(data);
						if (response.choices && response.choices.length > 0) {
							const description = response.choices[0].message.content.trim();
							resolve(description);
						} else {
							resolve(null);
						}
					} else {
						console.error(`Erreur API OpenAI: ${res.statusCode}`);
						console.error(data);
						resolve(null);
					}
				} catch (error) {
					console.error('Erreur lors du parsing de la réponse OpenAI:', error.message);
					resolve(null);
				}
			});
		});

		req.on('error', (error) => {
			console.error('Erreur lors de la requête à l\'API OpenAI:', error.message);
			resolve(null);
		});

		req.write(payload);
		req.end();
	});
}

/**
 * Analyse les changements avec l'IA
 */
async function analyzeWithAI(diff, ticketNumber, commitType) {
	if (config.aiProvider === 'claude') {
		return analyzeWithClaude(diff, ticketNumber, commitType);
	} else if (config.aiProvider === 'openai') {
		return analyzeWithOpenAI(diff, ticketNumber, commitType);
	}
	return null;
}

/**
 * Fonction principale
 */
async function main() {
	// Vérifier les arguments
	const args = process.argv.slice(2);
	if (args.includes('--config') || args.includes('-c')) {
		loadConfig();
		await setupConfig();
		return;
	}

	// Charger la configuration
	loadConfig();

	console.log('\n🚀 ACSEO Commit - Générateur de commits conventionnels');

	// Vérifier s'il y a des fichiers en attente de commit
	const changedFiles = getChangedFiles();

	if (changedFiles.length === 0) {
		console.log('\n⚠️ Aucun fichier en attente de commit. Utilisez git add pour ajouter des fichiers.');
		return;
	}

	// Afficher les fichiers modifiés
	displayChangedFilesSummary(changedFiles);

	// Demander le type de commit
	const commitType = await promptCommitType();

	// Demander le numéro de ticket
	const ticketNumber = await promptTicketNumber();

	// Demander si l'utilisateur veut ajouter un scope
	const scope = await promptScope();

	// Générer une description standard
	const standardDesc = generateSuggestedDescription(changedFiles);

	// Générer une description avec l'IA si configurée
	let aiDescription = null;

	if (config.apiKey) {
		console.log('\n🤖 Analyse des modifications avec IA en cours...');
		const diff = getFilesDiff();
		aiDescription = await analyzeWithAI(diff, ticketNumber, commitType);
	}

	// Demander la description
	let descOptions = '';
	if (aiDescription) {
		descOptions = `\n1. Standard: ${standardDesc}\n2. IA: ${aiDescription}\n3. Personnalisée\n\nChoisissez une option (1/2/3): `;
	}

	const rl = createReadlineInterface();
	const description = await new Promise((resolve) => {
		if (aiDescription) {
			rl.question(descOptions, (choice) => {
				rl.close();
				if (choice === '1') {
					resolve(standardDesc);
				} else if (choice === '2') {
					resolve(aiDescription);
				} else {
					// Ouvrir un nouveau RL car le précédent est fermé
					const rl2 = createReadlineInterface();
					rl2.question('\nEntrez votre description: ', (customDesc) => {
						rl2.close();
						resolve(customDesc.trim());
					});
				}
			});
		} else {
			rl.question(`\nDescription du commit [${standardDesc}]: `, (customDesc) => {
				rl.close();
				resolve(customDesc.trim() || standardDesc);
			});
		}
	});

	// Construire le message de commit
	let commitMessage;
	if (scope) {
		commitMessage = `${commitType}(#${ticketNumber}, ${scope}): ${description}`;
	} else {
		commitMessage = `${commitType}(#${ticketNumber}): ${description}`;
	}

	// Demander confirmation
	const confirmed = await confirmCommit(commitMessage);

	if (confirmed) {
		doCommit(commitMessage);
	} else {
		console.log('\n❌ Commit annulé par l\'utilisateur.');
	}
}

// Exécuter le programme
if (require.main === module) {
	main().catch(error => {
		console.error('Erreur:', error);
		process.exit(1);
	});
}

// Exposer pour les tests et autres utilisations
module.exports = {
	main,
	promptCommitType,
	promptTicketNumber,
	promptDescription,
	loadConfig,
	setupConfig
};